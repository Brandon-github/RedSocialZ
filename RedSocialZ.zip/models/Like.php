<?php

class Like extends Orm {
    protected static $table = 'likes';
}