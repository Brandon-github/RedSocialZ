## Ideas
Este archivo lo usaremos para definir las ideas del proyecto de la red social
como que tecnologias, patrones de diseño e integraciones que se usuaran y como vamos a implementarlas

Hasta el momento creo que usaremos la siguientes tecnologias segun vi en el grupo 

**Tecnologias**

- html
- css
- javascript
- php
- sql
- c++

**Patrones de diseño**

- MVC(Model, View, Controller)

**Integraciones**

Segun vi era para que fuera mas eficiente el acceso a los datos...

- php con c++

## Progreso

Crear la base de datos para los datos de la red social

### Tablas

- Users
- Message
- Posts
- Likes
- Comments

#NoLolisXD