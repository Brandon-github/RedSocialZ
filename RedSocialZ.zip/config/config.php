<?php
namespace config;

const VERSION = '1.2-dev';
const DEVELOPMENT = TRUE;

const NAME_SEPARATOR = ' | ';
const APP_NAME = 'SocialCube';
const HASH_ID_SALT = 'qYR7JpZmdOGF';